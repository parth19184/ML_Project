load("train_input.mat");
load("train_label.mat");

KernelSize = [5, 1];    %   Default [5, 1]
MaxPoolSize = [3, 1];   %   Default [3, 1]
NumFeatures_conv = 32;  %   Default 32
NumFeatures_fc = 64;    %   Default 64
layers = cifar10(KernelSize, MaxPoolSize,NumFeatures_conv, NumFeatures_fc);

optim = 'sgdm';
batchsize= 128;
MaxEpochs = 10;      % Change it to 100 default value

opts_setting_1 = {'once',0.001,optim,batchsize,MaxEpochs;
                'once',0.0001,optim,batchsize,MaxEpochs};
opts_setting_2 = {'every-epoch',0.001,optim,batchsize,MaxEpochs;
                'every-epoch',0.0001,optim,batchsize,MaxEpochs};

opts = train_option(opts_setting_2{1,1},opts_setting_1{1,2},opts_setting_1{1,3},opts_setting_1{1,4},opts_setting_1{1,5});
cifar10_p1 = trainNetwork(train_input, train_label, layers, opts);

load("test_input");
load("test_label.mat");

confusionchart(train_label, classify(cifar10_p1, train_input));
confusionchart(test_label, classify(cifar10_p1, test_input));

subtract = grp2idx(classify(cifar10_p1, test_input)) - grp2idx(test_label);
acc = sum(subtract==0)/size(subtract, 1);