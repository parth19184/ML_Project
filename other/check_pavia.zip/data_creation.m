load("paviaU.mat");
load("PaviaU_gt.mat");

paviaU = double(paviaU);
paviaU_gt = double(paviaU_gt);

paviaU = reshape(paviaU, [size(paviaU, 1)*size(paviaU, 2), 103]);
paviaU_gt = reshape(paviaU_gt, [size(paviaU_gt, 1)*size(paviaU_gt, 2), 1]);
pavia_ds = [paviaU, paviaU_gt];
pavia_ds(pavia_ds(:,104)==0, :) = [];

train_ds = [];
test_ds = [];
class_sample = zeros(9,1);
counter = zeros(1,1);

for i=1:size(pavia_ds,1)
    if class_sample(pavia_ds(i, 104), 1)<0.1*sum(pavia_ds(i,104)==pavia_ds(:,104))
            train_ds = [train_ds; pavia_ds(i, :)];
            class_sample(pavia_ds(i, 104), 1) = class_sample(pavia_ds(i, 104), 1) + 1;
    else
            test_ds = [test_ds; pavia_ds(i, :)];
    end
    counter = counter + 1
end

% train_ds = pavia_ds(1:8600,:);
% test_ds = pavia_ds(8601:42776,:);

train_input = train_ds(:,1:103);
train_label = train_ds(:,104);

test_input = test_ds(:,1:103);
test_label = test_ds(:,104);

train_input = train_input./(8000/255);
test_input = test_input./(8000/255);

train_input = reshape(train_input, [size(train_input, 2), 1, 1, size(train_input, 1)]);
train_label = categorical(train_label);

test_input = reshape(test_input, [size(test_input, 2), 1, 1, size(test_input, 1)]);
test_label = categorical(test_label);