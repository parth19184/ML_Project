function layers = cifar10(KernelSize, MaxPoolSize,NumFeatures_conv, NumFeatures_fc)
inputLayer = imageInputLayer([103 1 1]);

% Convolutional layer parameters
filterSize = KernelSize;
numFilters = NumFeatures_conv;
numImageCategories = 9;
numChannels = 1;

% Cifar10 Network Definition
middleLayers = [
    convolution2dLayer(filterSize,numFilters,'Padding',[2 0])
 %   batchNormalizationLayer
    reluLayer()
    %maxPooling2dLayer([2 1],'Stride',[2 1])
    maxPooling2dLayer(MaxPoolSize,'Stride',[2 1])
    
    convolution2dLayer(filterSize,numFilters,'Padding',[2 0])
 %   batchNormalizationLayer
    reluLayer()
    %maxPooling2dLayer([2 1], 'Stride',[2 1])
    maxPooling2dLayer(MaxPoolSize,'Stride',[2 1])
    
   convolution2dLayer(filterSize,2 * numFilters,'Padding',[2 0])
 %  batchNormalizationLayer
   reluLayer()
    %maxPooling2dLayer([2 1],'Stride',[2 1])
   maxPooling2dLayer(MaxPoolSize,'Stride',[2 1])
    ];

finalLayers = [
     fullyConnectedLayer(NumFeatures_fc)
     reluLayer
    fullyConnectedLayer(numImageCategories)
    softmaxLayer
    classificationLayer
    ];

layers = [
    inputLayer
    middleLayers
    finalLayers
    ];

%initialise weights
layers(2).Weights = 0.0001 * randn([filterSize numChannels numFilters]);
%opts = train_opt;
return 